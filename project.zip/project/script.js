<script>
       /* $("#demo_4").ionRangeSlider({
        skin: "round",
        grid: true,
        min:0,
        max: 12.8,
        from: 0,
        to: 3.2,
        step: 0.1,
        postfix: " mBTC",
    }); */
    // Position of span that shows range value and tick curve position
const tickContainer = document.querySelector('.range-wrap');

const range = document.getElementById('range');
const rangeV = document.getElementById('rangeValue');
const setValue = () => {
  // Span position and inner value
  const newValue = Number((range.value - range.min) * 100 / (range.max - range.min));
  const newPosition = 30 - (newValue * 0.6);
  rangeV.style.left = `calc(${newValue}% + (${newPosition}px))`;
  rangeV.innerHTML = `${range.value} mBTC`;
  
  // Tick curve position
  tickContainer.style.setProperty('--p', `calc(${newValue}%)`);
};

// Initialize setValue onload and oninput
document.addEventListener("DOMContentLoaded", setValue);
range.addEventListener('input', setValue);
    </script>